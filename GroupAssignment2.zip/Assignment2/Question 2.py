'''
The following python codes are written for Question 2

Authors:
Zelija Adhikari - S394736

Anshul Joshi - S388454

Zain ul Aman - S387290

Hasib Rahman - S390781

'''


# Importing paths and data frames
from pathlib import Path
import pandas as pd
import numpy as np

# Reading the files
DATA_DIR = Path.home() / "Desktop" / "temperatures"

# This list will define the month columns in the files
MONTHS = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
]

# This mapping will convert month numbers to Australian seasons
SEASON_MAP = {
    12: "Summer", 1: "Summer", 2: "Summer",
    3: "Autumn", 4: "Autumn", 5: "Autumn",
    6: "Winter", 7: "Winter", 8: "Winter",
    9: "Spring", 10: "Spring", 11: "Spring"
}

# This function will load one CSV and reshape to long format
def load_one_csv(path: Path) -> pd.DataFrame:
    # This line will read the CSV
    df = pd.read_csv(path)
    # This line will keep only the needed columns
    keep_cols = ["STATION_NAME"] + [m for m in MONTHS if m in df.columns]
    df = df[keep_cols].copy()
    # This line will melt month columns to rows
    long_df = df.melt(
        id_vars="STATION_NAME",
        value_vars=[c for c in MONTHS if c in df.columns],
        var_name="MonthName",
        value_name="Temp"
    )
    # This line will map month names to month numbers 1..12
    month_to_num = {m: i + 1 for i, m in enumerate(MONTHS)}
    long_df["Month"] = long_df["MonthName"].map(month_to_num)
    # This line will coerce temperature to numeric and drop NaN
    long_df["Temp"] = pd.to_numeric(long_df["Temp"], errors="coerce")
    long_df = long_df.dropna(subset=["Temp", "Month"])
    # This line will rename station column to a simple name
    long_df = long_df.rename(columns={"STATION_NAME": "Station"})
    return long_df[["Station", "Month", "Temp"]]

# This function will load and combine all CSV files and also return the names that were read
def load_all_data(folder: Path) -> tuple[pd.DataFrame, list[str]]:
    # This list will store each year’s long dataframe
    frames: list[pd.DataFrame] = []
    # This list will store the names of successfully read CSVs
    read_names: list[str] = []
    # This loop is for every .csv file in the folder
    for csv_path in sorted(folder.glob("*.csv")):
        try:
            df_long = load_one_csv(csv_path)
            if not df_long.empty:
                frames.append(df_long)
                read_names.append(csv_path.name)
            else:
                print(f"Note: {csv_path.name} had no usable rows.")
        except Exception as e:
            print(f"Skipping {csv_path.name}: {e}")
    # This line will concatenate everything (or make an empty frame)
    if frames:
        combined = pd.concat(frames, ignore_index=True)
    else:
        combined = pd.DataFrame(columns=["Station", "Month", "Temp"])
    return combined, read_names

# This function will compute seasonal averages across all stations and years
def seasonal_averages(df: pd.DataFrame) -> pd.Series:
    # This line will map month to season
    df = df.copy()
    df["Season"] = df["Month"].map(SEASON_MAP)
    # This line will compute the mean temperature per season
    s = df.groupby("Season")["Temp"].mean().round(1)
    # This line will order the seasons in the usual order
    return s.reindex(["Summer", "Autumn", "Winter", "Spring"])

# This function will compute per-station min, max, range, and std deviation
def station_stats(df: pd.DataFrame) -> pd.DataFrame:
    # This groupby will compute stats per station ignoring NaNs
    g = df.groupby("Station")["Temp"]
    stats = pd.DataFrame({
        "Min": g.min(),
        "Max": g.max(),
        "Range": g.max() - g.min(),
        "StdDev": g.std(ddof=1)  # sample std dev
    })
    # This line will fill NaN std dev (e.g., only one value) with 0
    stats["StdDev"] = stats["StdDev"].fillna(0.0)
    return stats

# This function will write "Summer: 28.5°C" style lines
def write_average_temp(out_path: Path, seasonal: pd.Series) -> None:
    lines = [f"{k}: {v:.1f}°C" for k, v in seasonal.items() if pd.notna(v)]
    out_path.write_text("\n".join(lines), encoding="utf-8")
    print(f"Wrote {out_path}")

# This function will write stations with largest temperature range (handles ties)
def write_largest_range(out_path: Path, stats: pd.DataFrame) -> None:
    max_range = stats["Range"].max()
    winners = stats[stats["Range"] == max_range].sort_index()
    lines = [
        f"{station}: Range {row['Range']:.1f}°C (Max: {row['Max']:.1f}°C, Min: {row['Min']:.1f}°C)"
        for station, row in winners.iterrows()
    ]
    out_path.write_text("\n".join(lines), encoding="utf-8")
    print(f"Wrote {out_path}")

# This function will write most stable (smallest std dev) and most variable (largest std dev) stations (handles ties)
def write_stability(out_path: Path, stats: pd.DataFrame) -> None:
    min_std = stats["StdDev"].min()
    max_std = stats["StdDev"].max()
    stable = stats[stats["StdDev"] == min_std].sort_index()
    variable = stats[stats["StdDev"] == max_std].sort_index()
    lines: list[str] = []
    for station, row in stable.iterrows():
        lines.append(f"Most Stable: {station}: StdDev {row['StdDev']:.1f}°C")
    for station, row in variable.iterrows():
        lines.append(f"Most Variable: {station}: StdDev {row['StdDev']:.1f}°C")
    out_path.write_text("\n".join(lines), encoding="utf-8")
    print(f"Wrote {out_path}")

# This function will print a text file to the console
def print_file(path: Path) -> None:
    # This line will read the file and print with a header and footer
    print(f"\n----- {path.name} START -----")
    try:
        print(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        print("(file not found)")
    print(f"----- {path.name} END -----\n")

# This function will run everything
def main():
    # This will check the folder
    if not DATA_DIR.exists():
        print(f"Folder not found: {DATA_DIR}")
        return

    # This will load all data and collect file names that were read
    df, read_files = load_all_data(DATA_DIR)

    # This will print how many CSVs were read and list their names
    print(f"CSV files successfully read: {len(read_files)}")
    for name in read_files:
        print(f" - {name}")

    if df.empty:
        print("No usable data found. Check CSV headers and folder.")
        return

    # This will compute the results
    seasonal = seasonal_averages(df)
    stats = station_stats(df)

    # This will write outputs next to the temperatures folder (on Desktop)
    out_avg = DATA_DIR.parent / "average_temp.txt"
    out_range = DATA_DIR.parent / "largest_temp_range_station.txt"
    out_stab = DATA_DIR.parent / "temperature_stability_stations.txt"

    write_average_temp(out_avg, seasonal)
    write_largest_range(out_range, stats)
    write_stability(out_stab, stats)

    # This will print the contents of the three output files to the console
    print_file(out_avg)
    print_file(out_range)
    print_file(out_stab)

    # This line will print a summary
    print(f"Rows used: {len(df)} | Stations: {stats.shape[0]}")

# This will run the program 
if __name__ == "__main__":
    main()
