'''
The following python codes are written for Question 1

Authors:
Zelija Adhikari - S394736

Anshul Joshi - S388454

Zain ul Aman - S387290

Hasib Rahman - S390781

'''

# Importing the necessary libraries

from pathlib import Path
from typing import Dict, Tuple

LOWER = "abcdefghijklmnopqrstuvwxyz"
UPPER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

def build_cipher_maps(shift1: int, shift2: int) -> Tuple[Dict[str, str], Dict[str, str]]:
    # This function will build the encryption map for lower and upper, then build the inverse map for decryption
    enc: Dict[str, str] = {}

    # lowercase
    for ch in LOWER:
        idx = ord(ch) - ord('a')
        shift = (shift1 * shift2) if ch <= 'm' else -(shift1 + shift2)
        enc[ch] = chr(ord('a') + ((idx + shift) % 26))

    # uppercase
    for ch in UPPER:
        idx = ord(ch) - ord('A')
        shift = (-shift1) if ch <= 'M' else (shift2 ** 2)
        enc[ch] = chr(ord('A') + ((idx + shift) % 26))

    # inverse for decryption
    dec = {v: k for k, v in enc.items()}
    return enc, dec

def transform(text: str, mp: Dict[str, str]) -> str:
    # This function will apply a character map; non-letters stay unchanged
    return "".join(mp.get(c, c) for c in text)

def is_bijection_for_case(enc: Dict[str, str], alphabet: str) -> bool:
    # This function will check if mapping is one-to-one for a given alphabet
    return len({enc[c] for c in alphabet}) == len(alphabet)

def main():
    # This block will point paths to the Desktop
    desktop = Path.home() / "Desktop"
    raw_path = desktop / "raw_text.txt"
    enc_path = desktop / "encrypted_text.txt"
    dec_path = desktop / "decrypted_text.txt"

    if not raw_path.exists():
        print(f"Could not find: {raw_path}")
        return

    # This will read shifts
    try:
        shift1 = int(input("Enter shift1: ").strip())
        shift2 = int(input("Enter shift2: ").strip())
    except ValueError:
        print("Please enter integer values for shift1 and shift2.")
        return

    # This will build maps
    enc_map, dec_map = build_cipher_maps(shift1, shift2)

    # This section will read the raw file and print it 
    plaintext = raw_path.read_text(encoding="utf-8")
    print(f"\nRead {len(plaintext)} characters from: {raw_path}")
    print("----- RAW FILE CONTENT START -----")
    print(plaintext)
    print("----- RAW FILE CONTENT END -----\n")

    # Optional note about invertibility
    if not (is_bijection_for_case(enc_map, LOWER) and is_bijection_for_case(enc_map, UPPER)):
        print("Note: with these shifts the mapping may not be perfectly invertible; "
              "decrypted text might not match exactly.")

    # This will encrypt and write
    encrypted = transform(plaintext, enc_map)
    enc_path.write_text(encrypted, encoding="utf-8")
    print(f"Encrypted → {enc_path}")

    # This will decrypt and write
    decrypted = transform(encrypted, dec_map)
    dec_path.write_text(decrypted, encoding="utf-8")
    print(f"Decrypted → {dec_path}")

    # This if-else statement will verify
    if decrypted == plaintext:
        print("Verification SUCCESS: decrypted text matches the original.")
    else:
        print("Verification FAILED: decrypted text does not match the original.")

if __name__ == "__main__":
    main()
