'''
The following python codes are written for Question 3

Authors:
Zelija Adhikari - S394736

Anshul Joshi - S388454

Zain ul Aman - S387290

Hasib Rahman - S390781

'''

# Importing tkinter and turtle
import tkinter as tk
import turtle as T
import math
from typing import List, Tuple


# This function will recursively build the segments for one edge with an inward indentation
def build_edge_segments(length: float, depth: int, heading: float,
                        start: Tuple[float, float]) -> List[Tuple[Tuple[float, float], Tuple[float, float]]]:
    # This condition will stop the recursion at depth 0 and return one straight segment
    if depth == 0:
        end = (start[0] + length * math.cos(math.radians(heading)),
               start[1] + length * math.sin(math.radians(heading)))
        return [(start, end)]
    # This variable will store the sub length which is 1/3 of the original
    L = length / 3.0
    segs = []
    # This sequence will make the inward equilateral 'V' with +60, -120, +60
    segs += build_edge_segments(L, depth - 1, heading, start)
    segs += build_edge_segments(L, depth - 1, heading + 60, segs[-1][1])
    segs += build_edge_segments(L, depth - 1, heading - 60, segs[-1][1])
    segs += build_edge_segments(L, depth - 1, heading,     segs[-1][1])
    return segs


# This function will build all segments for the whole polygon and center them
def build_polygon_segments(n_sides: int, side_len: float, depth: int) -> List[Tuple[Tuple[float, float], Tuple[float, float]]]:
    # This variable will store the exterior turn after each edge
    turn = 360.0 / n_sides
    heading = 0.0
    start = (0.0, 0.0)
    segs: List[Tuple[Tuple[float, float], Tuple[float, float]]] = []
    # This loop is for creating all edges of the polygon
    for _ in range(n_sides):
        part = build_edge_segments(side_len, depth, heading, start)
        segs.extend(part)
        start = part[-1][1]
        heading += turn
    # This section will center the coordinates around (0,0)
    xs = [p[0] for s in segs for p in s]
    ys = [p[1] for s in segs for p in s]
    cx, cy = (min(xs) + max(xs)) / 2.0, (min(ys) + max(ys)) / 2.0
    segs = [((x1 - cx, y1 - cy), (x2 - cx, y2 - cy)) for (x1, y1), (x2, y2) in segs]
    return segs


# This function will scale segments to fit into the canvas with margins
def scale_to_canvas(segments, canvas_w=900, canvas_h=900, margin=30):
    xs = [p[0] for s in segments for p in s]
    ys = [p[1] for s in segments for p in s]
    w = max(xs) - min(xs) if xs else 1.0
    h = max(ys) - min(ys) if ys else 1.0
    # This variable will store the scale so the drawing fits inside the canvas
    sx = (canvas_w - 2 * margin) / w if w else 1.0
    sy = (canvas_h - 2 * margin) / h if h else 1.0
    k = min(sx, sy)
    # This section will apply the scale
    return [((x1 * k, y1 * k), (x2 * k, y2 * k)) for (x1, y1), (x2, y2) in segments]


# This function will draw all segments with RawTurtle on a Tk 8.5 canvas
def draw_segmentsTk(segments, root: tk.Tk, canvas: tk.Canvas):
    # This section will create the TurtleScreen and RawTurtle
    screen = T.TurtleScreen(canvas)
    screen.bgcolor("white")
    t = T.RawTurtle(screen)
    # This block will configure the turtle for visibility 
    t.hideturtle()
    t.speed(9)          
    t.pencolor("black")
    t.pensize(2)
    t.penup()
    # This if-else statement will start at the first point and draw each segment
    if not segments:
        return
    (x0, y0), _ = segments[0]
    t.goto(x0, y0)
    t.pendown()
    for (_, _), (x2, y2) in segments:
        t.goto(x2, y2)
    # This call will flush the drawing so it appears immediately
    try:
        screen.update()
    except Exception:
        pass
    return screen, t


# This function will set up the window, read inputs, print stats, and start drawing
def main() -> None:
    # This block will read the user inputs
    n = int(input("Enter the number of sides: ").strip())
    side = float(input("Enter the side length: ").strip())
    depth = int(input("Enter the recursion depth: ").strip())

    # This block will print progress information
    segments_count = n * (4 ** depth)
    total_len = n * side * ((4 / 3) ** depth)
    print("Drawing... this may take a few seconds at higher depths.")
    print(f"Segments to draw: {segments_count}")
    print(f"Approx total path length: {total_len:.2f} px")

    # This block will build and scale the drawing so it always fits the canvas
    segs = build_polygon_segments(n, side, depth)
    segs = scale_to_canvas(segs, canvas_w=900, canvas_h=900, margin=40)

    # This section will create a Tk 8.5 window and canvas with a white background
    root = tk.Tk()
    root.title("Fractal polygon — inward indentation (Tk 8.5 friendly)")
    width, height = 900, 900
    canvas = tk.Canvas(root, width=width, height=height, bg="white", highlightthickness=0)
    canvas.pack()

    try:
        root.lift()
        root.attributes("-topmost", True)
        root.after(300, lambda: root.attributes("-topmost", False))
    except Exception:
        pass

    # This statement will draw the fractal with the turtle
    screen, t = draw_segmentsTk(segs, root, canvas)

    # This line will save a vector image
    try:
        canvas.postscript(file="fractal diagram as output.eps")
        print("Saved fractal.eps which can be later converted as PNG or JPEG")
    except Exception as e:
        print("EPS export skipped:", e)
    
    # End of Program
    print("End of program.")
    root.mainloop()


# This is the main function will run the program
if __name__ == "__main__":
    main()
